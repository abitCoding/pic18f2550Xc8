
/*
 * LED(s) testing on PIC18F2550 USB Board
 * Testing program is written using MPLABX
 * XC8 C compiler for 8-bit PIC.
 */
#include <xc.h>
#include "configPic18f2550.h"

/*Clock frequency parameter for delay function
 *Microcontroller operates at 20MHz from external
 *crystal oscillator
 */
#define _XTAL_FREQ  20e6

/*LED(s) labels*/
#define LED1    RC1
#define LED1Dir TRISC1
#define LED2    RC2
#define LED2Dir TRISC2

void myDelay(unsigned int _ms){
    for(unsigned int i=0;i<_ms;i++)
    __delay_ms(1);
}
int main(void){
    /*Clear PortC*/
    PORTC=0x00;
    /*LED1 output direction*/
    LED1Dir=0;
    /*LED2 output direction*/
    LED2Dir=0;
    while(1){
        LED1=0;
        LED2=1;
        myDelay(1000);
        LED1=1;
        LED2=0;
        myDelay(1000);
    }
}
